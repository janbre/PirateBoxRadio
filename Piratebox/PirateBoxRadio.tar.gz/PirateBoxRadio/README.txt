Add to /etc/group
icecast:x:200:

Add to /etc/passwd
icecast:*:200:200:nobody:/var:/bin/ash
